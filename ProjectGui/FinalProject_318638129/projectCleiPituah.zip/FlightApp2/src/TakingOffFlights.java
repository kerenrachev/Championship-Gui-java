

import java.io.PrintWriter;
import java.sql.Time;
import java.time.LocalDateTime;

public class TakingOffFlights extends Flights {

	public TakingOffFlights(String name, String takeOffFrom, String destination, String time, String date) {
		super(name, takeOffFrom,destination,time,date);
	}



}
