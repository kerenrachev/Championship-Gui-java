
import java.time.LocalDateTime;

public class LandingFlights extends Flights {

	

	public LandingFlights(String company, String takesOffFrom, String destination, String time, String date) {
		super (company, takesOffFrom,destination,time,date);
	}
}
